# Prompt de auditoria antes de compras reais

Audite este projeto CotaBot by SaborGestão como revisão pré-produção. Inspecione código, SQL, RLS, autenticação, tokens de fornecedores, logs, segredos, duplicidade de propostas, validação de valores, isolamento multiempresa, backup e falhas de rede.

Não assuma que a existência de uma política RLS significa que está segura: verifique cada tabela e função RPC, incluindo SECURITY DEFINER, search_path, permissões EXECUTE e validação de papel/empresa. Verifique se a chave service_role aparece em qualquer arquivo público ou commit.

Produza uma tabela com severidade (crítica/alta/média/baixa), evidência concreta (arquivo e trecho), impacto, correção proposta e teste de confirmação. Diferencie problemas comprovados de hipóteses. Não afirme que a aplicação passou em testes sem executá-los. Termine com decisão: bloqueada para produção, apta para piloto controlado ou apta para produção, justificando cada requisito.
