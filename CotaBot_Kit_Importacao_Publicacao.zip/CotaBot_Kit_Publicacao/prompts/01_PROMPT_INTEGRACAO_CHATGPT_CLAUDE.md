# Prompt para concluir a integração do CotaBot

Você é um engenheiro full-stack sênior. Trabalhe com os arquivos deste pacote, sem presumir funcionalidades que não existam. O objetivo é transformar o protótipo CotaBot by SaborGestão em uma aplicação web multiusuário usando Supabase/PostgreSQL, Supabase Auth, RLS e um deploy HTTPS.

Arquivos-base:
- public/index.html: painel atual; ainda usa localStorage e deve ser tratado como protótipo.
- public/formulario_fornecedor.html: formulário externo preparado para Supabase.
- supabase/supabase_schema.sql: esquema inicial do formulário e convites.

Entregue mudanças reais nos arquivos, não apenas explicações. Preserve o fluxo e o visual existentes sempre que possível.

Requisitos obrigatórios:
1. Audite primeiro o HTML, SQL e formulário. Liste riscos, funções incompletas e incompatibilidades antes de alterar.
2. Integre login/logout e sessão segura; perfis MASTER, DIRETOR, ADMIN e OPERADOR, com associação a empresa/unidade.
3. Configure RLS para que uma empresa não leia ou altere dados de outra. O navegador nunca deve conter service_role nem segredo privado.
4. Substitua gradualmente localStorage como fonte oficial dos dados por operações no Supabase. Pode manter dados demonstrativos apenas em modo demonstração claramente identificado.
5. Integre a criação de cotações do painel ao RPC seguro de criação de convites e gere links individuais com expiração/revogação.
6. Faça respostas do formulário aparecerem no painel de comparação, evitando duplicidades e validando preço, quantidade, prazo e campos obrigatórios no servidor.
7. Preserve seleção automática por menor preço, confirmação parcial, itens sem cotação destacados, prazos de entrega e impressão/PDF, mas não aprove compras automaticamente sem regra explícita.
8. Inclua `.env.example` sem segredos, instruções de configuração e deploy, tratamento de erros, validações e logs sem dados sensíveis.
9. Inclua testes de isolamento entre duas empresas, login, cotação, convite expirado, proposta duplicada, resposta do fornecedor e persistência após sair/entrar.
10. Não declare pronto para produção até os testes serem executados. Não invente credenciais, URLs, resultados de testes nem serviços conectados.

Formato de entrega:
- arquivos completos atualizados;
- SQL/migrations necessários;
- checklist passo a passo para alguém sem experiência técnica;
- instruções exatas de importação para GitHub e publicação HTTPS;
- lista clara do que ainda depende de configuração manual.
