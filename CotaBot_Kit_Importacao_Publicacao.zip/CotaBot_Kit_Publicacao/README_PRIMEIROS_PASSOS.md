# CotaBot by SaborGestão — Kit de publicação inicial

Este pacote organiza os arquivos para importar no GitHub e publicar um ambiente de teste.

## O que está incluído
- `public/index.html`: painel CotaBot v17, ainda protótipo local com `localStorage`.
- `public/formulario_fornecedor.html`: formulário externo preparado para Supabase, requer URL e chave publicável.
- `supabase/supabase_schema.sql`: estrutura SQL inicial do formulário e convites.
- `docs/CONFIGURACAO_FORMULARIO.md`: instruções de configuração existentes.
- `prompts/`: prompts para usar no ChatGPT ou Claude para revisar e concluir a integração.

## Limite importante
Publicar este pacote sozinho NÃO torna o sistema multiusuário. O painel principal continua salvando os dados no navegador e ainda não cria convites no banco. O formulário também depende de configuração Supabase e de um convite válido criado por fluxo administrativo. Trate a publicação inicial apenas como ambiente de teste, sem dados comerciais reais.

## Caminho mais simples
1. Crie um projeto em https://supabase.com/.
2. No painel do Supabase, abra SQL Editor e execute `supabase/supabase_schema.sql`.
3. No arquivo `public/formulario_fornecedor.html`, configure `SUPABASE_URL` e `SUPABASE_ANON_KEY` com os valores do seu projeto. Use somente a chave publicável/anon no navegador; nunca use `service_role`.
4. Crie um repositório privado em https://github.com/new.
5. Envie o conteúdo desta pasta ao repositório, mantendo `public/index.html` e `public/formulario_fornecedor.html`.
6. Para publicar como site estático de teste, conecte o repositório a um serviço de hospedagem compatível e defina a pasta de saída como `public` (se a plataforma pedir). O arquivo principal será `/` e o formulário `/formulario_fornecedor.html`.
7. Não use em compras reais até o painel ser integrado ao Supabase, login/RLS serem testados e o fluxo completo ser validado.

## URLs oficiais
- Supabase: https://supabase.com/
- Guia Supabase Auth: https://supabase.com/docs/guides/auth
- Guia RLS: https://supabase.com/docs/guides/database/postgres/row-level-security
- GitHub: https://github.com/new
- Vercel: https://vercel.com/
- Netlify: https://www.netlify.com/
- WhatsApp Cloud API: https://developers.facebook.com/docs/whatsapp/cloud-api/overview

## Estrutura esperada após a integração
- Usuários autenticados e associados a uma empresa.
- Dados isolados por empresa via RLS.
- Painel lendo e gravando cotações no banco, não apenas no localStorage.
- Convites por fornecedor com token individual, expiração e revogação.
- Respostas de fornecedores refletidas na comparação do painel.
- Histórico de alterações, backups e fluxo de aprovação.
