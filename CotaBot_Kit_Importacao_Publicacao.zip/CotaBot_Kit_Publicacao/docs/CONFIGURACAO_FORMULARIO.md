# Configuração do formulário CotaBot

1. Crie um projeto no Supabase.
2. Abra **SQL Editor** e execute o conteúdo de `supabase_schema.sql`.
3. Em `formulario_fornecedor.html`, substitua:
   - `COLE_A_URL_DO_SEU_PROJETO` pela Project URL;
   - `COLE_A_CHAVE_ANON_PUBLICA` pela chave publicável/anon do projeto.
4. Hospede o HTML em um endereço HTTPS público (por exemplo, dentro do domínio da SaborGestão quando a hospedagem estiver pronta).
5. No banco, crie a empresa, os fornecedores e os insumos em `cb_companies`, `cb_suppliers` e `cb_products`.
6. Cadastre o usuário administrativo na tabela `cb_company_members` com papel `MASTER` ou `ADMIN`.
7. Integrar o painel CotaBot para chamar `cb_admin_create_quote`. O retorno contém token individual de cada fornecedor. Monte o link `https://SEU-DOMINIO/formulario_fornecedor.html?token=TOKEN` e prepare o WhatsApp para cada fornecedor.
8. Quando o fornecedor enviar o formulário, as respostas entram em `cb_supplier_responses` e `cb_supplier_response_items`.

## Teste rápido do formulário
Não tente abrir o formulário sem token: ele deve mostrar uma mensagem de link incompleto. Para testar ponta a ponta, a criação do convite precisa ocorrer pelo RPC administrativo autenticado após a etapa 6. Não gere token manualmente em produção.
