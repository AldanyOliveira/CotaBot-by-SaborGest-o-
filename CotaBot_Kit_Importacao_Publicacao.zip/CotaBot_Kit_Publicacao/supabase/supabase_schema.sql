-- CotaBot by SaborGestão — banco para cotação externa de fornecedores
-- Execute no SQL Editor do seu projeto Supabase.
create extension if not exists pgcrypto;

create table if not exists public.cb_companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.cb_suppliers (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.cb_companies(id) on delete cascade,
  name text not null,
  whatsapp text,
  categories text[] not null default '{}',
  payment_terms text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(company_id, name)
);

create table if not exists public.cb_products (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.cb_companies(id) on delete cascade,
  name text not null,
  category text not null,
  unit text not null default 'UND',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(company_id, name)
);

create table if not exists public.cb_quote_requests (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.cb_companies(id) on delete cascade,
  quote_code text not null,
  title text,
  closes_at timestamptz not null,
  status text not null default 'open' check (status in ('open','closed','cancelled')),
  notes text,
  created_by uuid,
  created_at timestamptz not null default now(),
  unique(company_id, quote_code)
);

create table if not exists public.cb_quote_items (
  id uuid primary key default gen_random_uuid(),
  quote_id uuid not null references public.cb_quote_requests(id) on delete cascade,
  product_id uuid references public.cb_products(id) on delete set null,
  product_name text not null,
  category text not null,
  unit text not null,
  requested_quantity numeric(14,3) not null check (requested_quantity > 0),
  created_at timestamptz not null default now()
);

create table if not exists public.cb_quote_invites (
  id uuid primary key default gen_random_uuid(),
  quote_id uuid not null references public.cb_quote_requests(id) on delete cascade,
  supplier_id uuid not null references public.cb_suppliers(id) on delete cascade,
  token_hash text not null unique,
  sent_at timestamptz,
  created_at timestamptz not null default now(),
  unique(quote_id, supplier_id)
);

create table if not exists public.cb_supplier_responses (
  id uuid primary key default gen_random_uuid(),
  quote_id uuid not null references public.cb_quote_requests(id) on delete cascade,
  supplier_id uuid not null references public.cb_suppliers(id) on delete cascade,
  payment_terms text,
  delivery_days integer check (delivery_days is null or delivery_days >= 0),
  supplier_notes text,
  submitted_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(quote_id, supplier_id)
);

create table if not exists public.cb_supplier_response_items (
  id uuid primary key default gen_random_uuid(),
  response_id uuid not null references public.cb_supplier_responses(id) on delete cascade,
  quote_item_id uuid not null references public.cb_quote_items(id) on delete cascade,
  unit_price numeric(14,4) not null check (unit_price >= 0),
  offered_quantity numeric(14,3) not null check (offered_quantity >= 0),
  available boolean not null default true,
  brand text,
  notes text,
  unique(response_id, quote_item_id)
);

create index if not exists cb_quotes_company_status_idx on public.cb_quote_requests(company_id, status, closes_at);
create index if not exists cb_quote_items_quote_idx on public.cb_quote_items(quote_id);
create index if not exists cb_invites_quote_supplier_idx on public.cb_quote_invites(quote_id, supplier_id);
create index if not exists cb_responses_quote_idx on public.cb_supplier_responses(quote_id, supplier_id);

alter table public.cb_companies enable row level security;
alter table public.cb_suppliers enable row level security;
alter table public.cb_products enable row level security;
alter table public.cb_quote_requests enable row level security;
alter table public.cb_quote_items enable row level security;
alter table public.cb_quote_invites enable row level security;
alter table public.cb_supplier_responses enable row level security;
alter table public.cb_supplier_response_items enable row level security;

-- No public table access. Public supplier interactions happen only through the
-- narrowly scoped RPC functions below. Authenticated dashboard policies should
-- be added when connected to the real multi-tenant app, using company membership.

create or replace function public.cb_supplier_quote_get(p_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_invite public.cb_quote_invites%rowtype;
  v_quote public.cb_quote_requests%rowtype;
  v_supplier public.cb_suppliers%rowtype;
  v_company public.cb_companies%rowtype;
  v_items jsonb;
  v_response public.cb_supplier_responses%rowtype;
  v_answers jsonb;
begin
  if p_token is null or length(p_token) < 24 then
    raise exception 'Link de cotação inválido.';
  end if;

  select * into v_invite
  from public.cb_quote_invites
  where token_hash = encode(digest(p_token, 'sha256'), 'hex');

  if not found then raise exception 'Link de cotação inválido ou expirado.'; end if;
  select * into v_quote from public.cb_quote_requests where id = v_invite.quote_id;
  select * into v_supplier from public.cb_suppliers where id = v_invite.supplier_id;
  select * into v_company from public.cb_companies where id = v_quote.company_id;

  select coalesce(jsonb_agg(jsonb_build_object(
    'id', qi.id, 'name', qi.product_name, 'category', qi.category,
    'unit', qi.unit, 'quantity', qi.requested_quantity
  ) order by qi.product_name), '[]'::jsonb)
  into v_items from public.cb_quote_items qi where qi.quote_id = v_quote.id;

  select * into v_response from public.cb_supplier_responses
  where quote_id = v_quote.id and supplier_id = v_supplier.id;

  if found then
    select coalesce(jsonb_agg(jsonb_build_object(
      'quote_item_id', ri.quote_item_id, 'unit_price', ri.unit_price,
      'offered_quantity', ri.offered_quantity, 'available', ri.available,
      'brand', ri.brand, 'notes', ri.notes
    )), '[]'::jsonb) into v_answers
    from public.cb_supplier_response_items ri where ri.response_id = v_response.id;
  else
    v_answers := '[]'::jsonb;
  end if;

  return jsonb_build_object(
    'quote_id', v_quote.id,
    'quote_code', v_quote.quote_code,
    'company_name', v_company.name,
    'supplier_name', v_supplier.name,
    'closes_at', v_quote.closes_at,
    'status', v_quote.status,
    'notes', v_quote.notes,
    'payment_terms', v_supplier.payment_terms,
    'items', v_items,
    'existing_response', case when v_response.id is null then null else jsonb_build_object(
      'payment_terms', v_response.payment_terms,
      'delivery_days', v_response.delivery_days,
      'supplier_notes', v_response.supplier_notes,
      'items', v_answers
    ) end,
    'can_submit', (v_quote.status = 'open' and now() <= v_quote.closes_at)
  );
end;
$$;

create or replace function public.cb_supplier_quote_submit(
  p_token text,
  p_payment_terms text,
  p_delivery_days integer,
  p_supplier_notes text,
  p_items jsonb
) returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_invite public.cb_quote_invites%rowtype;
  v_quote public.cb_quote_requests%rowtype;
  v_supplier public.cb_suppliers%rowtype;
  v_response_id uuid;
  v_item jsonb;
  v_quote_item_id uuid;
  v_unit_price numeric(14,4);
  v_offered_qty numeric(14,3);
  v_available boolean;
  v_brand text;
  v_notes text;
  v_valid_count integer := 0;
begin
  if p_token is null or length(p_token) < 24 then raise exception 'Link inválido.'; end if;
  select * into v_invite from public.cb_quote_invites
    where token_hash = encode(digest(p_token, 'sha256'), 'hex');
  if not found then raise exception 'Link de cotação inválido ou expirado.'; end if;
  select * into v_quote from public.cb_quote_requests where id = v_invite.quote_id;
  select * into v_supplier from public.cb_suppliers where id = v_invite.supplier_id;

  if v_quote.status <> 'open' or now() > v_quote.closes_at then
    raise exception 'O prazo desta cotação foi encerrado.';
  end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'Informe os preços dos itens antes de enviar.';
  end if;

  insert into public.cb_supplier_responses(quote_id, supplier_id, payment_terms, delivery_days, supplier_notes, updated_at)
  values (v_quote.id, v_supplier.id, nullif(trim(p_payment_terms),''), p_delivery_days, nullif(trim(p_supplier_notes),''), now())
  on conflict (quote_id, supplier_id) do update set
    payment_terms = excluded.payment_terms,
    delivery_days = excluded.delivery_days,
    supplier_notes = excluded.supplier_notes,
    submitted_at = now(),
    updated_at = now()
  returning id into v_response_id;

  delete from public.cb_supplier_response_items where response_id = v_response_id;

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    v_quote_item_id := (v_item->>'quote_item_id')::uuid;
    if not exists (select 1 from public.cb_quote_items where id=v_quote_item_id and quote_id=v_quote.id) then
      raise exception 'Um dos itens não pertence a esta cotação.';
    end if;
    v_unit_price := (v_item->>'unit_price')::numeric;
    v_offered_qty := (v_item->>'offered_quantity')::numeric;
    v_available := coalesce((v_item->>'available')::boolean, true);
    v_brand := nullif(trim(v_item->>'brand'),'');
    v_notes := nullif(trim(v_item->>'notes'),'');
    if v_unit_price < 0 or v_offered_qty < 0 then raise exception 'Preço e quantidade não podem ser negativos.'; end if;
    insert into public.cb_supplier_response_items(response_id, quote_item_id, unit_price, offered_quantity, available, brand, notes)
    values (v_response_id, v_quote_item_id, v_unit_price, v_offered_qty, v_available, v_brand, v_notes);
    v_valid_count := v_valid_count + 1;
  end loop;

  return jsonb_build_object('success', true, 'response_id', v_response_id, 'items_saved', v_valid_count);
end;
$$;

revoke all on function public.cb_supplier_quote_get(text) from public, anon, authenticated;
revoke all on function public.cb_supplier_quote_submit(text,text,integer,text,jsonb) from public, anon, authenticated;
grant execute on function public.cb_supplier_quote_get(text) to anon, authenticated;
grant execute on function public.cb_supplier_quote_submit(text,text,integer,text,jsonb) to anon, authenticated;

-- Create a quote and supplier invitations from the authenticated admin app.
-- The app must call this function with an authenticated user's company_id after
-- enforcing membership/role. In this starter, admin RPC is deliberately not
-- granted to anon and should only be exposed after auth/RLS integration.
create or replace function public.cb_admin_create_quote(
  p_company_id uuid,
  p_quote_code text,
  p_closes_at timestamptz,
  p_notes text,
  p_items jsonb,
  p_supplier_ids uuid[]
) returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_quote_id uuid;
  v_supplier_id uuid;
  v_item jsonb;
  v_product_id uuid;
  v_item_id uuid;
  v_token text;
  v_links jsonb := '[]'::jsonb;
begin
  if auth.uid() is null then raise exception 'Autenticação obrigatória.'; end if;
  if p_closes_at <= now() then raise exception 'A data e hora de encerramento devem estar no futuro.'; end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items)=0 then raise exception 'Adicione ao menos um insumo.'; end if;
  if coalesce(array_length(p_supplier_ids,1),0)=0 then raise exception 'Selecione ao menos um fornecedor.'; end if;
  -- Tenant membership validation must be connected to the production app.
  -- This starter denies creation until a membership table/policy is installed.
  if not exists (
    select 1 from information_schema.tables
    where table_schema='public' and table_name='cb_company_members'
  ) then raise exception 'Configure cb_company_members e as regras de acesso antes de criar cotações.'; end if;
  if not exists (
    select 1 from public.cb_company_members m
    where m.company_id=p_company_id and m.user_id=auth.uid() and m.role in ('MASTER','ADMIN')
  ) then raise exception 'Sem permissão para esta empresa.'; end if;

  insert into public.cb_quote_requests(company_id, quote_code, closes_at, notes, created_by)
  values(p_company_id, p_quote_code, p_closes_at, nullif(trim(p_notes),''), auth.uid())
  returning id into v_quote_id;

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    v_product_id := nullif(v_item->>'product_id','')::uuid;
    if v_product_id is not null and not exists(select 1 from public.cb_products where id=v_product_id and company_id=p_company_id) then
      raise exception 'Insumo inválido para esta empresa.';
    end if;
    insert into public.cb_quote_items(quote_id, product_id, product_name, category, unit, requested_quantity)
    values(v_quote_id, v_product_id, v_item->>'product_name', v_item->>'category', v_item->>'unit', (v_item->>'quantity')::numeric)
    returning id into v_item_id;
  end loop;

  foreach v_supplier_id in array p_supplier_ids
  loop
    if not exists(select 1 from public.cb_suppliers where id=v_supplier_id and company_id=p_company_id and active) then
      raise exception 'Fornecedor inválido para esta empresa.';
    end if;
    v_token := encode(gen_random_bytes(32),'hex');
    insert into public.cb_quote_invites(quote_id,supplier_id,token_hash)
    values(v_quote_id,v_supplier_id,encode(digest(v_token,'sha256'),'hex'));
    v_links := v_links || jsonb_build_array(jsonb_build_object(
      'supplier_id',v_supplier_id,
      'supplier_name',(select name from public.cb_suppliers where id=v_supplier_id),
      'whatsapp',(select whatsapp from public.cb_suppliers where id=v_supplier_id),
      'token',v_token
    ));
  end loop;
  return jsonb_build_object('quote_id',v_quote_id,'quote_code',p_quote_code,'invitations',v_links);
end;
$$;
revoke all on function public.cb_admin_create_quote(uuid,text,timestamptz,text,jsonb,uuid[]) from public, anon;
grant execute on function public.cb_admin_create_quote(uuid,text,timestamptz,text,jsonb,uuid[]) to authenticated;

-- Company membership is the authorization boundary for admin users.
create table if not exists public.cb_company_members (
  company_id uuid not null references public.cb_companies(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('MASTER','ADMIN','OPERATOR','DIRECTOR')),
  primary key(company_id,user_id)
);
alter table public.cb_company_members enable row level security;
create policy cb_company_members_read_self on public.cb_company_members
  for select to authenticated using (user_id=auth.uid());

-- NOTE: This schema intentionally grants no direct table permissions to anon.
-- Add authenticated table policies only as part of the production dashboard integration.
